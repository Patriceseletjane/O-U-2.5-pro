# O/U 2.5 Pro — fixed Android project

This replaces the broken Android project structure.

Important: `app/src/main/AndroidManifest.xml` is included.
The GitHub Actions workflow builds `app-debug.apk` and uploads it as an artifact.
