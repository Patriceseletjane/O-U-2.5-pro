# Over 2.5 Pro — Final Boss v3

Android decision-support app for Over 2.5 football analysis.

## Included
- Previous-score analysis
- Over 2.5 rate calculation
- Average-goals calculation
- Odds-aware heuristic scoring
- 5% bankroll cap suggestion
- WAIT / LEAN / STRONGER signal
- GitHub Actions APK build
- No bookmaker login or bet placement

## Build
Push to `main`, then open GitHub Actions and run **Build Over 2.5 Pro APK**.
The APK is uploaded as a workflow artifact.

## Important
This is a heuristic decision-support tool. It does not provide guaranteed predictions or guaranteed profit, and virtual football outcomes can be unpredictable.
