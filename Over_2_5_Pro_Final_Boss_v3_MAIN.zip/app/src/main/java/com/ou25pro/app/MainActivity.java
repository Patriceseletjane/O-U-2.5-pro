package com.ou25pro.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    EditText resultsInput, oddsInput, bankrollInput;
    TextView resultView, historyView;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(dp(4), dp(5), dp(4), dp(5));
        return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(8,12,18));

        TextView title = tv("OVER 2.5 PRO", 28, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView sub = tv("FINAL BOSS v3  •  Virtual Football Prediction Assistant", 14, Color.LTGRAY, false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        resultsInput = field("Previous results  •  e.g. 3-1, 2-2, 1-3, 4-0, 2-1");
        oddsInput = field("Over 2.5 odds  •  e.g. 1.70");
        bankrollInput = field("Bankroll (₦)  •  e.g. 10000");

        root.addView(resultsInput);
        root.addView(oddsInput);
        root.addView(bankrollInput);

        Button analyze = new Button(this);
        analyze.setText("ANALYZE MATCH");
        analyze.setTextColor(Color.WHITE);
        analyze.setBackgroundColor(Color.rgb(45, 150, 95));
        root.addView(analyze, new LinearLayout.LayoutParams(-1, dp(52)));

        resultView = tv("Prediction result will appear here.", 16, Color.WHITE, true);
        resultView.setPadding(dp(12), dp(14), dp(12), dp(14));
        root.addView(resultView);

        historyView = tv("Session history: no predictions yet.", 13, Color.LTGRAY, false);
        root.addView(historyView);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        analyze.setOnClickListener(v -> analyze());
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.GRAY);
        e.setTextColor(Color.WHITE);
        e.setSingleLine(false);
        e.setPadding(dp(8), dp(10), dp(8), dp(10));
        return e;
    }

    void analyze() {
        String raw = resultsInput.getText().toString();
        double odds = parseDouble(oddsInput.getText().toString(), 1.70);
        double bankroll = parseDouble(bankrollInput.getText().toString(), 0);

        Pattern p = Pattern.compile("(\\d+)\\s*[-:]\\s*(\\d+)");
        Matcher m = p.matcher(raw);
        int n=0, over=0, goals=0;
        while (m.find()) {
            int a = Integer.parseInt(m.group(1));
            int b = Integer.parseInt(m.group(2));
            n++;
            goals += a+b;
            if (a+b >= 3) over++;
        }

        if (n == 0) {
            resultView.setText("Enter at least 3 previous scorelines, e.g. 3-1, 2-2, 1-3, 4-0, 2-1.");
            return;
        }

        double overRate = (double)over/n;
        double avgGoals = (double)goals/n;

        // Heuristic only: not a guarantee or validated probability model.
        double score = 0;
        score += overRate * 60.0;
        score += Math.min(avgGoals / 4.0, 1.0) * 25.0;
        if (odds >= 1.60 && odds <= 1.90) score += 10;
        else if (odds < 1.40 || odds > 2.20) score -= 5;
        score = Math.max(0, Math.min(99, score));

        String signal = score >= 75 ? "STRONGER OVER 2.5 SIGNAL" :
                        score >= 60 ? "LEAN OVER 2.5" : "WAIT / LOW CONFIDENCE";

        double stake = bankroll > 0 ? bankroll * 0.05 : 0;

        String out = String.format(Locale.US,
            "%s\n\nHeuristic score: %.0f/99\nHistorical Over 2.5 rate: %.0f%%\nAverage goals: %.2f\nOdds: %.2f\nSuggested max stake: ₦%.0f\n\nThis is decision support, not a guarantee. Virtual results can be random.",
            signal, score, overRate*100, avgGoals, odds, stake);

        resultView.setText(out);
        historyView.setText("Last analysis: " + signal + "  •  " + new Date().toString());
    }

    double parseDouble(String s, double fallback) {
        try { return Double.parseDouble(s.replace(",", "").trim()); }
        catch(Exception e) { return fallback; }
    }
}
